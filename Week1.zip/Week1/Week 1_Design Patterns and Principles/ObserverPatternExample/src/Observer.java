public interface Observer {
    void update(String stockPrice);
}
