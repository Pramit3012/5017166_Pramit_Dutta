public class MobileApp implements Observer {
    private String stockPrice;
    public void update(String stockPrice) {
        this.stockPrice = stockPrice;
        display();
    }

    public void display() {
        System.out.println("MobileApp - Stock Price Updated: " + stockPrice);
    }
}

