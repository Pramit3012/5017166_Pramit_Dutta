public class AdapterPatternExample {
    public static void main(String[] args) {
        PayPal payPal = new PayPal();
        Stripe stripe = new Stripe();
        PaymentProcessor payPalProcessor = new PayPalAdapter(payPal);
        PaymentProcessor stripeProcessor = new StripeAdapter(stripe);
        payPalProcessor.processPayment(100.00);
        stripeProcessor.processPayment(200.00);
    }
}
