public class Stripe {
    public void sendPayment(double amount) {
        System.out.println("Payment of " + amount + " processed using Stripe.");
    }
}
