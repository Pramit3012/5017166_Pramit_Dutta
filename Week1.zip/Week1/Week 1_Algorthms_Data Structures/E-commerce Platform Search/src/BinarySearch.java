public class BinarySearch {
    public static void sortProducts(Product[] products) {
        for (int i = 0; i < products.length - 1; i++) {
            for (int j = 0; j < products.length - 1 - i; j++) {
                if (products[j].getProductId() > products[j + 1].getProductId()) {
                    // Swap products[j] and products[j + 1]
                    Product temp = products[j];
                    products[j] = products[j + 1];
                    products[j + 1] = temp;
                }
            }
        }
    }

    public static Product binarySearch(Product[] products, int targetId) {

        sortProducts(products);

        int left = 0;
        int right = products.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (products[mid].getProductId() == targetId) {
                return products[mid];
            }
            else if (products[mid].getProductId() < targetId) {
                left = mid + 1;
            }
            else {
                right = mid - 1;
            }
        }


        return null;
    }
    public static void main(String[] args) {
        Product[] products = {
                new Product(1, "Laptop", "Electronics"),
                new Product(2, "Shirt", "Clothing"),
                new Product(3, "Gas Oven", "Kitchen"),
                new Product(4, "Headphones", "Electronics"),
                new Product(5, "Book", "Books")
        };

        Product result = binarySearch(products, 3);

        if (result != null) {
            System.out.println("Product found: " + result);
        } else {
            System.out.println("Product not found");
        }
    }
}