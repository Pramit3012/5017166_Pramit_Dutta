public class Main {
    public static void main(String[] args) {
        EmployeeManagement ems = new EmployeeManagement(10);
        ems.addEmployee(new Employee(1, "Pramit", "Manager", 75000));
        ems.addEmployee(new Employee(2, "Arka", "Developer", 60000));
        ems.addEmployee(new Employee(3, "Mainak", "Designer", 50000));
        System.out.println("All Employees:");
        ems.traverseEmployees();
        System.out.println("\nSearching for Employee with ID 2:");
        Employee emp = ems.searchEmployee(2);
        if (emp != null) {
            System.out.println(emp);
        } else {
            System.out.println("Employee not found");
        }
        System.out.println("\nDeleting Employee with ID 2:");
        if (ems.deleteEmployee(2)) {
            System.out.println("Employee deleted successfully");
        } else {
            System.out.println("Employee not found");
        }
        System.out.println("\nAll Employees after deletion:");
        ems.traverseEmployees();
    }
}
