package com.book.BookstoreAPI.exception;

public class NoContentException extends RuntimeException {
    public NoContentException(String message) {
        super(message);
    }
}
