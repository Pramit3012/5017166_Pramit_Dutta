package com.library.service;

public class BookService {
    public void printMessage() {
        System.out.println("Hello from BookService!");
    }
}