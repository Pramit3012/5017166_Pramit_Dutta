package com.library.repository;

public class BookRepository {
    public void printMessage() {
        System.out.println("Hello from BookRepository!");
    }
}